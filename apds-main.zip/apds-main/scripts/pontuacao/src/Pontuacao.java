public interface Pontuacao {
    public float calcularPontos(); //todo método em interface é abstrato
}