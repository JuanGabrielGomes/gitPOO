package capitulo5.exercicios.exercicio2;

public interface Pontuacao {
    public float calcularPontos();
}
