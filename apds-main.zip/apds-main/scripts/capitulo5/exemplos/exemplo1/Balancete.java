package capitulo5.exemplos.exemplo1;

public interface Balancete {

    public float declararDespesa();
}
