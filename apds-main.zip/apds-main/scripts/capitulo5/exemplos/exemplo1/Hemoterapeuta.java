package capitulo5.exemplos.exemplo1;

public final class Hemoterapeuta extends Medico{
    private boolean acreditado;

    public boolean isAcreditado() { 
        return acreditado;
    }

    public void setAcreditado(boolean acreditado) {
        this.acreditado = acreditado;
    }
}
