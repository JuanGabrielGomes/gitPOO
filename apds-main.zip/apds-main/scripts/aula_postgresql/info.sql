create table Info(id integer, Cost integer, city varchar(200));
insert into Info(id, Cost,city) values(1, 100,'Natal');
insert into Info(id, Cost,city) values(2, 100, 'Macaiba');
insert into Info(id, Cost,city) values(3, 65,'Parnamirim');
insert into Info(id, Cost,city) values(4, 97,'Extremoz');
insert into Info(id, Cost,city) values(5, 12,'CearaMirim');
select * from Info;